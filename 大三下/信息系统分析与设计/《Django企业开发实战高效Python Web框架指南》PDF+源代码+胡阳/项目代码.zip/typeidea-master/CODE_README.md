# typeidea
Django企业开发实战对应项目代码

说明：

视频对应的分支是：chapter7，chapter8，这样的。

书对应的分支是：book/*开头的。
