## Typeidea 介绍

这个是完整的博客系统，master代码是基于 Python3.6 和 Django2.0 开发。

也是[《Django企业开发实战》](http://django-practice-book.com/)图书和对应的一套[视频](http://django-practice-book.com/course.html)的代码。

不同的载体和章节的内容分别在不同的分支中，你可以通过分支名来区分是视频还是图书，以及对应的章节，比如：

分支 ``book/05-initproject`` 就是对应的图书的第五章的代码，``book/06-admin`` 就是对应的第六章的代码。
而对应的 ``chapter7``、``chapter8``这样的是视频章节对应的代码。
