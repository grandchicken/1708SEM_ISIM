import matplotlib.pyplot as plt


dic = {'a': 22, 'b': 10, 'c': 6, 'd': 4, 'e': 2, 'f': 10, 'g': 24, 'h': 16, 'i': 1, 'j': 12}
s = sorted(dic.items(), key=lambda x: x[1], reverse=False)  # 对dict 按照value排序 True表示翻转 ,转为了列表形式
x_x = []
y_y = []
for i in s:
    x_x.append(i[0])
    y_y.append(i[1])

x = x_x
y = y_y

fig, ax = plt.subplots()
ax.barh(x, y, color="deepskyblue")
labels = ax.get_xticklabels()
plt.setp(labels, rotation=0, horizontalalignment='right')

for a, b in zip(x, y):
    plt.text(b+1, a, b, ha='center', va='center')
ax.legend(["label"],loc="lower right")

plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.ylabel('name')
plt.xlabel('数量')
plt.title("title")

plt.show()