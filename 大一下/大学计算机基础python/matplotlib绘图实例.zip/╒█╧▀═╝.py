#5.2-subplot.py

#为了在生成的图像中显示中文，需要设置字体属性
import matplotlib.pyplot as plt  #导入matplotlib.pyplot模块，别名取为plt
from matplotlib.font_manager import FontProperties
#设置字体对象，本例选择的是简宋字体，字号是14
font = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=14)

x = [1,2,3,4,5,6]
y1,y2 = [78,69,80,75,69,89],[80,68,72,81,70,77]

fig,ax = plt.subplots(2,1)   					#创建2个子图
plt.sca(ax[0])                		   		#选择子图1
plt.plot(x, y1, 'ro-',linewidth=2.5)
plt.ylabel(u'分数', fontproperties=font)
plt.title(u'二年级各班语文平均成绩变化趋势图', fontproperties=font)
plt.ylim(0,+100)
plt.sca(ax[1])              				#选择子图2
plt.plot(x, y2, 'bo-',linewidth=2.5)
plt.ylabel(u'分数', fontproperties=font)
plt.title(u'三年级各班语文平均成绩变化趋势图', fontproperties=font)
plt.ylim(0,+100)

plt.show()
