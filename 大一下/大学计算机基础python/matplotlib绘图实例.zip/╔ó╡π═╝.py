#-*- coding: utf-8 -*-
#5.8-scatter.py


import matplotlib.pyplot as plt  #导入matplotlib.pyplot模块，别名取为plt
import numpy as np          #导入numpy库，别名起为np

plt.rcParams['font.sans-serif'] = ['SimHei']
#为了在生成的图像中显示中文，需要设置字体属性
from matplotlib.font_manager import FontProperties
#设置字体对象，本例选择的是简宋字体，字号是14
pic_font = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=14) 
plt.figure(figsize=(9,6))
				#共有10个班
male_height=[163,164,165,168,169,170,170,170,171,172,172,172,173,173,174
,175,175,175,175,175,176,178,178,180,180,183]
male_weight=[60,56,60,55,60,54,80,64,67,65,60
,60,60,62,65,70,70,65,60,62,58,70,75,63,71,75]
female_height=[153,156,156,157,158,158,159,160,160,160,160,161,161,162,162
,163,163,163,164,164,165,165,165,168,168,170]
female_weight=[42,44,38,48,52,45,43,50,45,52,50,50,45,55,60,56
,56,59,55,47,45,45,60,58,49,54]
						 #T:散点的颜色
plt.scatter(male_height,male_weight,s=50,marker='o')  #绘制散点图，s：散点的大小，alpha:透明程度
plt.scatter(female_height,female_weight,s=50,marker='d')  #绘制散点图，s：散点的大小，alpha:透明程度
plt.legend(("男生","女生"))
plt.axvline(x=np.mean(male_height),color='red',linestyle='--')
plt.axvline(x=np.mean(female_height),color='b',linestyle='--')
plt.axhline(y=np.mean(male_weight),color='red',linestyle='--')
plt.axhline(y=np.mean(female_weight),color='b',linestyle='--')

plt.xlabel(u'身高（cm）', fontproperties=pic_font)
plt.ylabel(u'体重（kg）', fontproperties=pic_font)

plt.title(u'某大学男女生身高体重采样', fontproperties=pic_font)

plt.show()
