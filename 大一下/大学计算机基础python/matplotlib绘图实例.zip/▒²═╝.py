#-*- coding: utf-8 -*-
#5.7-pie.py

import matplotlib.pyplot as plt  #导入matplotlib.pyplot模块，别名取为plt
import numpy as np          #导入numpy库，别名起为np


#为了在生成的图像中显示中文，需要设置字体属性
from matplotlib.font_manager import FontProperties


data = [55,63,80,75,69,89,92,91,50,84,86,77,95,81,92,74,60,88,64,71]
#通过规则求解BEST,GOOD,PASS,FAIL，从略
BEST,GOOD,PASS,FAIL = 0,0,0,0
for score in data:
    if score < 60:
        FAIL = FAIL + 1
    elif score < 80:
        PASS = PASS + 1
    elif score < 90:
        GOOD = GOOD + 1
    else:
        BEST = BEST + 1

sizes = BEST,GOOD,PASS,FAIL
labels =[u'优', u'良', u'中',u'差'] 
#设置各个子块的填充颜色
colors = ['blue', 'orange', 'lime', 'lightgray']
#突出显示第二项，即得分为良的学生所占的比例
explode = (0.1, 0, 0, 0)
pie = plt.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=-90) 		#绘制饼状图

for font in pie[1]:
    font.set_fontproperties(FontProperties(fname=r"c:\windows\fonts\simsun.ttc"))

plt.show()
