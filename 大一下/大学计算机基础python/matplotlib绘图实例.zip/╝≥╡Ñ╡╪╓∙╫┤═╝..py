import numpy as np
import matplotlib.pyplot as plt

import matplotlib
matplotlib.rcParams['font.family'] = 'YouYuan'


AMean = [75, 77, 85]
BMean = [72, 88, 87]
CMean = [70, 85, 88]

ind = np.arange(0,3,1)  # 分成3组
width = 0.25       # 每个柱子的宽度

fig, ax = plt.subplots()    #创建一个子图
#绘制第一个柱状图A
rects1 = ax.bar(ind, AMean, width,hatch='/',edgecolor='black',color='white',label='A')
#绘制第二个柱状图B
rects2 = ax.bar(ind + width, BMean, width, hatch='*',edgecolor='black',color='white',label='B')
#绘制第三个柱状图C
rects3 = ax.bar(ind+2*width ,CMean,width,hatch='·',edgecolor='black',color='white',label='C')

ax.set_xticks(ind+width)
ax.set_xticklabels( ('第一次', '第二次', '第三次') )
plt.ylabel('成绩')
plt.legend(bbox_to_anchor=(0.14,0.78))

plt.show()