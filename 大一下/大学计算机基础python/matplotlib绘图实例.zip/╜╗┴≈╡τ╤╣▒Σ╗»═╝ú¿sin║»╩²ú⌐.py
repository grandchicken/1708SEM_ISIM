# 交流电压变化图（sin函数）

import matplotlib.pyplot as plt
import numpy as np


font = 'SimSun'

t = np.arange(0.0,2.01,0.01)
s = np.sin(2*np.pi*t)
Y = t*0


plt.plot(t,s,linewidth=2.5)
plt.plot(t,Y,'r-',linewidth=1.0)

plt.xlabel(u'时间(s)',fontproperties=font,size = 14)
plt.ylabel(u'电压(mV)',fontproperties=font,size = 14)

plt.title(u'电压瞬时变化图',fontproperties=font,size =14)

plt.show()