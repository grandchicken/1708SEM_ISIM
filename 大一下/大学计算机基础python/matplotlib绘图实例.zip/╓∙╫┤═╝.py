#-*- coding: utf-8 -*-
#5.5-bar.py


import matplotlib.pyplot as plt  #导入matplotlib.pyplot模块，别名取为plt
import numpy as np          #导入numpy库，别名起为np


#为了在生成的图像中显示中文，需要设置字体属性
from matplotlib.font_manager import FontProperties
#设置字体对象，本例选择的是简宋字体，字号是14
pic_font = FontProperties(fname=r"c:\windows\fonts\simsun.ttc", size=14)

data  = [(75,6),(72,5),(70,3),(77,8), (88,10),(85,6),(85,7),(87,9),(88,8)]


chineseMean ,chineseStd = [],[]
mathMean,mathStd = [],[]
englishMean,englishStd = [],[]

for i in range(0,len(data),3):
    chineseMean.append(data[i][0]),chineseStd.append(data[i][1])
    mathMean.append(data[i+1][0]),mathStd.append(data[i+1][1])
    englishMean.append(data[i+2][0]),englishStd.append(data[i+2][1])
    
N = 3
plt.rcParams['font.sans-serif'] = ['SimHei']


ind = np.arange(N)  # the x locations for the groups
width = 0.25       # the width of the bars

#设置语文、数学、英语的柱状图填充形式
pattern1,pattern2,pattern3 ="/","*","."
#这里处理原始数据，将原始数据分为三组，篇幅所限，从略，请查看源码
fig, ax = plt.subplots()    #创建一个子图
#绘制语文成绩柱状图
rects1 = ax.bar(ind, chineseMean, width,hatch=pattern1,edgecolor='black',color='white', yerr=chineseStd)
#绘制数学成绩柱状图
rects2 = ax.bar(ind + width, mathMean, width, hatch=pattern2,edgecolor='black',color='white', yerr=mathStd)
#绘制英语成绩柱状图
rects3=ax.bar(ind+2*width,englishMean,width,hatch=pattern3,edgecolor='black',color='white', yerr=englishStd)

#设置语文、数学、英语成绩的图例，位置为图表的左上角
ax.legend((rects1[0], rects2[0],rects3[0]), (u'语文', u'数学',u'英语'), prop={'family':'SimHei','size':8},loc='upper left',bbox_to_anchor=(0.04, 0.99))
#ax.legend((rects1[0], rects2[0],rects3[0]), (u'语文', u'数学',u'英语'), prop={'family':'SimHei','size':14},loc='upper center', bbox_to_anchor=(0.12,1.0),ncol=3)
#定义标注柱形图高度的函数
def autolabel(rects):
   for rect in rects:
      height = rect.get_height() 		#获得柱形的高度
      ax.text(rect.get_x() + rect.get_width()/2., 1.05*height,'%d' % int(height),ha='center', va='bottom')		#添加文本

#调用autolabel函数，在柱状图上标注高度
autolabel(rects1)
autolabel(rects2)
autolabel(rects3)
ax.set_ylabel('分数')

plt.title(u'二年级语文、数学和英语成绩')

ax.set_xticks(ind+width)
ax.set_xticklabels( ('二年级一班', '二年级二班', '二年级三班') )

plt.show()
