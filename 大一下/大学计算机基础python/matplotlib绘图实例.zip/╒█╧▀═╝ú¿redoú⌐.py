import matplotlib.pyplot as plt
font = 'STXINGKAI'

x = [1,2,3,4,5,6]
y1,y2 = [78,69,80,75,69,89],[80,68,72,81,70,77]

plt.subplot(2,1,1)
plt.plot(x, y1, 'ro-',linewidth=2.5)
plt.ylabel(u'分数', fontproperties=font,size = 14)
plt.title(u'二年级各班语文平均成绩变化趋势图', fontproperties=font, size = 14)
plt.axis([0.5,6.5,0,100])

plt.subplot(2,1,2)
plt.plot(x, y2, 'bo-',linewidth=2.5)
plt.ylabel(u'分数', fontproperties=font,size = 14)
plt.title(u'三年级各班语文平均成绩变化趋势图', fontproperties=font,size =14)
plt.axis([0.5,6.5,0,100])

plt.show()