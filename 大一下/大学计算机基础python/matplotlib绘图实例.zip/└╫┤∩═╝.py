#-*- coding: utf-8 -*-
#5.9-radar.py

import numpy as np
from matplotlib import pyplot as plt
fig=plt.figure(figsize=(10,5))
ax1=fig.add_subplot(1,1,1,polar=True) #设置坐标轴为极坐标体系

yg={"动力":74,"油耗":89,"操控":90,"配置":87,"安全":90,"空间":62} #创建车辆数据
kmr={"动力":76,"油耗":89,"操控":85,"配置":93,"安全":90,"空间":55} 


data1=np.array([i for i in yg.values()]).astype(int) #提取车辆信息
data2=np.array([i for i in kmr.values()]).astype(int) 
label=np.array([j for j in yg.keys()]) #提取标签
angle = np.linspace(0, 2*np.pi, len(data1), endpoint=False) #data里有几个数据，就把整圆360°分成几份
angles = np.concatenate((angle, [angle[0]])) #角度数组首尾闭合
data1 = np.concatenate((data1, [data1[0]])) #数据数组首尾闭合
data2 = np.concatenate((data2, [data2[0]])) 

ax1.set_thetagrids(angles*180/np.pi, label, fontproperties="Microsoft Yahei") #设置网格标签
ax1.plot(angles,data1,"o-")#画雷达多边形线
ax1.plot(angles,data2,"*-")
ax1.set_theta_zero_location('NW') #设置极坐标0°位置
ax1.set_rlim(0,100) #设置显示的极径范围
ax1.fill(angles,data1,facecolor='g', alpha=0.2) #填充颜色
ax1.fill(angles,data2,facecolor='b', alpha=0.2) #填充颜色
ax1.set_yticks((20,40,60,80,100))   #设置雷达图刻度
ax1.set_rlabel_position(255) #设置极径标签位置
ax1.set_title("本田雅阁与丰田凯美瑞对比",fontproperties="SimHei",fontsize=16) #设置标题
plt.legend(('雅阁', '凯美瑞'),prop={'family':'SimHei','size':14},loc='best')


plt.show()
