with open('明文.txt','r',encoding='utf-8') as file_1:
    p = file_1.read()
p_bin = bin(int(p))[2:]

with open("密钥.txt",'r',encoding='utf-8') as file_2:
    key = file_2.read()
    

# 密文二进制串分组
p_list = []
length = len(p_bin)
if length > 64:
    complete = length // 64
    rest = length % 64
    for i in range(complete):
        p_list.append(p_bin[i*64:64*(i+1)])
    
    p_list.append(p_bin[64*(complete):])

    if len(p_list[-1]) < 64:
        minus = 64 - len(p_list[-1])
        temp = '0'*minus + p_list.pop()
        p_list.append(temp)
elif length == 64:
    p_list.append(p_bin)
else:
    minus = 64 - len(p_bin)
    temp = '0'*minus + p_bin
    p_list.append(temp)

# 初始置换函数
def ini_change(i):
    res = i[57]+i[49]+i[41]+i[33]+i[25]+i[17]+i[9]+i[1]+i[59]+i[51]+i[43]+i[35]+i[27]+i[19]+i[11]+i[3]+i[61]+i[53]+i[45]+i[37]+i[29]+i[21]+i[13]+i[5]+i[63]+i[55]+i[47]+i[39]+i[31]+i[23]+i[15]+i[7]+i[56]+i[48]+i[40]+i[32]+i[24]+i[16]+i[8]+i[0]+i[58]+i[50]+i[42]+i[34]+i[26]+i[18]+i[10]+i[2]+i[60]+i[52]+i[44]+i[36]+i[28]+i[20]+i[12]+i[4]+i[62]+i[54]+i[46]+i[38]+i[30]+i[22]+i[14]+i[6]
    return res
# 逆置换函数
def re_change(i):
    res = i[39]+i[7]+i[47]+i[15]+i[55]+i[23]+i[63]+i[31]+i[38]+i[6]+i[46]+i[14]+i[54]+i[22]+i[62]+i[30]+i[37]+i[5]+i[45]+i[13]+i[53]+i[21]+i[61]+i[29]+i[36]+i[4]+i[44]+i[12]+i[52]+i[20]+i[60]+i[28]+i[35]+i[3]+i[43]+i[11]+i[51]+i[19]+i[59]+i[27]+i[34]+i[2]+i[42]+i[10]+i[50]+i[18]+i[58]+i[26]+i[33]+i[1]+i[41]+i[9]+i[49]+i[17]+i[57]+i[25]+i[32]+i[0]+i[40]+i[8]+i[48]+i[16]+i[56]+i[24]
    return res

print(ini_change(p_list[0]))



