############  第一章  ###########



#########################################################
              #####  Section 1： 工作环境设置   ######

setwd('I:/R learning/3 Finance with R')  
setwd('I:\\R learning\\3 Finance with R') 
   # 斜杠“ / ” ，或双反斜杠“ \\ ”
rm(list = ls())     # 清除内存空间里的所有对象，为新写脚本文件作准备              









#########################################################
              ######     Section 2： 数据对象   ######

             

### 1. 对象 
x <- 8
ls()        # List Objects：展示对象
rm(x)
rm(list=ls())






### 2. 基本数据类型，5种：【数字逻复、时】*
# 1) numeric 
x <- 12
length(x)
class(x)


# 2) character*
z <- "Display \"a\" string "   
    # 字符，须以“双引号、或单引号”引起来 
    # 双引号中、再引用“字符串中的双引号”，需用反斜杠“ \ ”隔开
z    ;   print(z)   
w <- 'Display "b"  string '
w    ;   cat(w)   
cat(z,w)          # Concatenate and Print：连结、并打印
class(z)  ;  class(w)


# 3) logical 
y <- TRUE
class(y)
length(y)


# 4) complex
m <- 2+3i
class(m)
length(m)




# 5) 时间型，日期/时间变量(***)：as.Date()、as.POSIXlt()、strftime() 
    ##  将“字符日期”，转换为“日期变量”(***)
(dates <- c("01/27/2016", "02/27/2016", "01/14/2016", "02/28/2016", "02/01/2016"))
is.numeric.Date(dates)      # 是否“数值日期变量” -->显然不是
is.character(dates)
(date <- as.Date(dates, format = "%m/%d/%Y")) #as.Date将字符型变量按format的格式转化为日期变量,但不是数值型日期变量
(dateform <- format(date, "%m/%d/%Y"))# 日期变量，转换为“任意指定格式”的字符串
    
class(date)#检查date的类型,就是'Date'类型


    ##	 将“字符时间”，转换为“可计算的时间变量”(**)
x <- c("2016-02-08 10:07:52", "2016-08-07 19:33:02")
is.character(x)
    # 判定是否为字符型变量
as.POSIXlt(x, tz = "", format = "%Y-%m-%d %H:%M:%S")
(x <- strptime(x, "%Y-%m-%d %H:%M:%S", tz = ""))
    # 按“年月日 时分秒”转换为时间变量，与as.POSIXlt()等效、但格式略有不同


    ##	 将“时间变量”转换为“字符日期”(***)
strftime(x, format = "%m/%d/%Y")     
format(x, "%Y-%m-%d %a %b")                
    # 输出格式，转换成format指定的字符串日期
    








### 3. 向量(***)：创建(等差、重复)、索引、编辑、排序
    ## 1) 向量创建 
    ## 非规则序列
x1 <- c(1,13,25,97)    
    # concatenate：连结函数，生成“普通/非规则数据的向量”
x2 <- c("a", "b", "c", "d")        
x3 <- c(TRUE, FALSE, FALSE, TRUE)  
class(x1)            
mode(x1)
typeof(x1)           

    ## 等差序列(扩展：等比数列)
x <- c(1,2,3,4)       
(y <- 1:10)          
(z <- 3*2^(1:10))   
    # 将等差数列、放在指数上，即生成“等比数列”
1:10*2              
1:10^2
seq(1, -9)                      # 只给出首项和尾项数据，by自动匹配为1或-1
seq(1, -9, length.out = 5)     
seq(1, -9, by = -2)             
seq(1, by = 2, length.out = 10) 
    

    ## 重复序列
rep(1:3, 2)                     # Replicate：“重复生成”某一元素或对象
rep(1:3, each = 2)              
rep(1:3, c(2, 1, 2))            
rep(1:3, each = 2, length.out = 4)  
rep(1:3, each = 2, times = 3)  
    # 序列中“各个元素”分别重复两次，“整个序列”重复3次
rep(as.factor(c("因子1", "因子2", "因子3")), 3) 
    



    ## 2)  向量索引
    ## “中括号 + 下标”索引(元素的值)
vector <- c(11, 12, 13, 14)      # 创建向量
vector[1]                    # 查看第一个元素
vector[c(1, 4)]              
vector[-1]                  
vector[-c(1:3)]              
vector[c(TRUE, TRUE, FALSE, FALSE)]  
    # 通过“逻辑序列/向量”，查看前两个元素

    ## 按名称索引	
names(vector) <- c("one", "two", "three", "four")  
vector[c("one", "two", "four")]    
    # 查看名称为“one”,“two”,“four”的元素

    ## which索引“满足逻辑条件的元素位置”(***)
which(vector == 13)               
which(vector == c(11, 14))        # 向量中等于11和14的元素所在的位置
which(vector != 12)               
which(vector > 12 & vector < 14)  
which.max(vector)                 
which.min(vector)                 

    ## subset索引
subset(vector, vector > 11 & vector < 14)    # 检索向量中满足条件的元素

    ## match方式索引
match(vector, c(14, 11, 13))    
vector[match(vector, c(11, 14))]
    ## 值匹配符：%in%
c(11, 18) %in% vector       
    



    ## 3) 向量编辑：元素的扩展及删除
x <- c(1, 2, 3, 4)
(x <- c(x, c(7, 8, 9)))
(x <- append(x, 5:6, after=4))
(x <- x[-1])
(x <- x[-c(3:5)])
    # 多个元素的删除



    ## 4) 排序及倒序
x <- c(5, 6, 8, 7, 4, 1, 9)
x1 <- c("B", "A", "C")
x2 <- c(3, 2, NA, 1, 4, 5)
sort(x)     
sort(x, decreasing = TRUE)      
    # 数值型数据排序(默认为升序)
order(x)
x[order(x)]
sort(x1)                         
sort(x2, na.last = TRUE)        
rev(x)                           



    ## 5) 向量的描述性统计、算术、累积运算
(x <- round(runif(20,1,1000), digits = 2))     # 四舍五入，保留小数点2位
    ###  “d/p/q/r + 分布名称”，密/概/分/数 
    ###  离散型：binom(二项)，nbinom(负二项)，geom(几何)，hyper(超几何)，pois(泊松)
    ###  连续型：unif(均匀)，norm(正态)，chisq(卡方)，t(t)，f(F)，gamma(伽玛)，exp(指数)，beta(β)，triangle(三角)
    ###  更多分布函数： https://cran.r-project.org/web/views/Distributions.html
summary(x)    # 汇总
min(x)  ;  max(x)        # 极值区间，与range(x)类似
mean(x) ; median(x)      # 均值,中位数
var(x)        # 方差
sd(x) ; sqrt(var(x))     # 标准差,即方差的平方根
fivenum(x)    # 五数汇总（计算规则，基于中位数）
quantile(x)   # 四分位数（计算规则，完全基于分位数概念）
quantile(x,c(0, .33, .66, 1))      
    # 三分位数：指定“分位百分点”
mad(x)        # median average distance

round(x)      # 等价于{ round(x,0) },四舍五入、取整
floor(x)      # 向下取整
ceiling(x)    # 向上取整

sum(x)        # 元素求和
cumsum(x)     #累计求和：x1 x1+x2 x1+x2+x3 ... x1+x2+...+xn
cummax(x)  ; cummin(x)     # 累积最大值、累积最小值
prod(x)       #求乘积
cumprod(x)    # 累积积
cor(x,sin(x/20))           # 线性相关系数







### 4. 矩阵与数组(***)：创建、索引/筛选、编辑、运算
   ## 1) 矩阵创建
x <- c(1:10)      # 创建一个向量，作为矩阵的数据
(a <- matrix(x, nrow = 5, ncol = 2, byrow = T))     
    # 创建一个矩阵，定义矩阵的行数为5、列数为2，按行读取数据
(b <- matrix(x))
dim(b) <- c(5, 2)   
b
(c <- matrix(x, nrow = 5, ncol = 2,  byrow = F, 
             dimnames = list(c("r1", "r2", "r3", "r4", "r5"), c("c1", "c2"))))
length(c)    # 矩阵也是向量，其长度为矩阵元素的个数



    ## 2) 矩阵索引/筛选：“中括号 + 下标范围”
x <- c(1:10)
(a <- matrix(x, nrow = 5, ncol = 2, byrow = F, 
            dimnames = list(c("r1", "r2", "r3", "r4", "r5"), c("c1", "c2"))))
a[2, 1]           #根据位置索引
a["r2", "c1"]     #根据行和列的名称来索引
a[1, ]            # 检索第一行     
a[, 1]            #索引第一列
a[c(3:5), ]       
a[-c(2, 4), 2]
    # 默认drop值为真，将返回一个“维数尽可能低的对象”(此处为向量)，此处返回的是向量，横向输出
a[-c(2, 4), 2, drop = F]
#去掉了第二行与第四行后，再提取出第2列，提取出的第2列已经是删去第2行与第4行后的矩阵的第2列
#由于用了“drop = F”，因此索引的是“单列子矩阵”，而不会降维为向量
a[a[, 1]>3, ]     
    # 筛选条件为“比较表达式”时，依逻辑布尔值为真、筛选出“需要的矩阵的行或列”



    ## 3) 矩阵编辑：重置矩阵大小、行/列的合并与删除(*)
    ## 矩阵转化为向量
x <- c(1:10) #创建一个矩阵
(a <- matrix(x, ncol = 2, nrow = 5, byrow = T))
(b <- as.vector(a))         # 将矩阵“转化为向量”
matrix(b, nrow=2)

(a <- matrix(1:10, nrow = 5, ncol = 2))
(a1 <- rbind(a, c(11,12)))     # 按行的形式、纵向合并，添加n行
(a2 <- cbind(a, c(11:15)))     # 按列的形式、横向合并，添加n列
(a3 <- rbind(a, 1))  
#按行合并是，短向量不足时，会循环补齐后再合并
(a4 <- cbind(a, 1))  
(a5 <- a[-1, ])      # 删除第一行
(a6 <- a[, -1])      # 删除第一列



    ## 4) 矩阵的运算
(A <- matrix(c(1:9), ncol = 3, nrow = 3))
(B <- matrix(c(9:1), ncol = 3, nrow = 3))
(C <- 2 * A + B - B / A)
    # 四则运算：加减乘除，要求两个矩阵同维、对应位置的元素做运算

colSums_A <- colSums(A)      # 对矩阵的各列求和 
colMeans_A <- colMeans(A)    # 对矩阵的各列求均值
rowSums(A)                   # 对矩阵的各行求和，直接显示
rowMeans(A)                  # 对矩阵的各行求均值
#想要对行/列求“方差、标准差……”等其他的函数运算，需要自己写代码，没有rowVar()
    

t(A)                  # 行/列转置
det(A)                #方阵求解行列式
(D <- A%*%B) #A%*%B是线性代数中矩阵的乘积
A * B  #不是普通矩阵的乘法，是矩阵的Hadamard积，对应元素相乘
kronecker(A, B)

crossprod(A, B)       
t(A) %*% B  #crossprod(A,B) = t(A) %*% B

outer(A,B)            
    # 矩阵“外积”(叉积，略)
A %o% B  
    # 等价于outer(A,B)

(D <- A %*% B)        
A * B                
kronecker(A, B)      

diag_A <- diag(A)          # 矩阵取对角
diag(diag_A)               # 生成对角阵
diag(3)       #输入参数为标量，生成单位阵 3x3的矩阵

(Tri <- matrix(1:25,5,5))     # 简化形式、指定行/列
(upper.tri(Tri))              # 返回“逻辑矩阵” ,对角线以上元素为True
Tri[upper.tri(Tri)] <- 0     
Tri                           

(M <- matrix(c(3:10, 30), ncol = 3, nrow = 3))   
solve(M)     
    # 求解逆矩阵，要求矩阵可逆(行列式不为0)
eigen(M)           
   #求矩阵的特征值与特征向量



    ## 5) 数组
x <- c(1:30)
dim1 <- c("A1", "A2", "A3")
dim2 <- c("B1", "B2", "B3", "B4", "B5")
dim3 <- c("C1", "c2")
(a <- array(x, dim = c(3, 5, 2), dimnames = list(dim1, dim2, dim3)))
    # 创建数组，数组维数为3(行、列、页/层)，各维度下标最大值为3、5、2


    ## 数组索引
a[2, 4, 1]               # 根据位置索引
a["A2", "B4", "C1"]      
dim(a)                   

    ## 数组维度重置
w <- 1:12
class(w)
dim(w) <- c(2,2,3)       
w
class(w)
as.vector(w)            










### 5. 列表(***)：创建、索引、编辑
    ## 1) 创建列表
    # (列表，是特殊的对象集合，其中的元素、可是“向量/矩阵/数组/字符串/其他列表”)
    # (每列、各元素/变量/字段/组件的class与length，均可以不同)
    # (对象，是类的实例；大多数对象，如函数的返回结果，都体现为列表)
(data <- list(a = c(1, 2, 3, 4), b = c("one", "two", "three"), 
              c = c(TRUE, FALSE), d = (1 + 2i)))
summary(data)        
    # 查看列表的数据结构

g <- "My List"                ;     class(g)
h <- c(25, 26, 18, 39)        ;     class(h)
j <- matrix(1:10, nrow = 5)   ;     class(j)
(mylist <- list(title = g, ages = h, j))  
    # 创建一个内含多种数据结构的列表
summary(mylist)      
names(mylist)     
   



    ## 2) 列表索引：(5种：下标 or 元素名 + 单括号 or 双括号 ; $元素名)
data[[1]]      ;    class(data[[1]])
data[1]        ;    class(data[1])
    # Lt["元素名"]，单重中括号取出的是“子列表”
data[["a"]]    
    # Lt[["元素名"]]，双重中括号(元素名字符、要加引号)、取出的是“列表元素”   
data$a         
data["a"]  
data[[1]][c(2, 4)]  
    



    ## 3) 列表编辑：赋值语句，或连接函数
data$e <- 5:8    ;    data
(data1 <- c(data, list(e = c(5, 6, 7, 8))))
(data2 <- c(data, e = list(c(5, 6, 7, 8))))  
 

data$a <- c("one","two", "three", "four")      ;    data 
    # 更改“列表元素a中的内容”
data$b <- NULL   ;    data
   

unlist <- unlist(data1)
    # 解体列表结构，转化为非列表对象、转化为“字符向量”
mode(unlist)  ; class(unlist)  ; typeof(unlist)










### 6.数据框(***)：创建、索引、编辑
    ## 1) 创建数据框：每列数据类型可不同，但长度必须相同
    ## 数据框，是一种特殊列表，以“矩阵形式”存放数据
data_iris <- data.frame(Sepal.Length = c(5.1, 4.9, 4.7, 4.6), 
                        Sepal.Width = c(3.5, 3.0, 3.2, 3.1), 
                        Petal.Length = c(1.4, 1.4, 1.3, 1.5),
                        Petal.Width = rep(0.2, 4))
data_iris

(data_matrix <- matrix(1:8, c(4, 2)))     # 创建一个矩阵
(data.frame(data_matrix))                 
    # 将矩阵转化为数据框



    ## 2) 数据框索引(矩阵、列表：两种方式索引**)
    ## 列索引
data_iris[, 1]                # 索引第一列
data_iris[[1]]                # 同上
data_iris$Sepal.Length        
class(data_iris$Sepal.Length)
data_iris[["Sepal.Length"]]  
data_iris["Sepal.Length"]    
class(data_iris["Sepal.Length"])

    ## 行索引
data_iris[1, ]        # 索引第一行
data_iris[1:3, ]      
    

    ## 元素索引
data_iris[1, 1]                 # 索引第一列第一个元素
data_iris$Sepal.Length[1]      
data_iris["Sepal.Length"][1]    

    ## subset函数索引(**)
subset(data_iris, Sepal.Length < 5)     
    data_iris[data_iris$Sepal.Length < 5, ]
    
    ## sqldf函数索引(略)
library(sqldf)
mtcars      # A data frame of R with 32 observations on 11 variables
(newdf <- sqldf("select * from mtcars where carb = 1 order by mpg", row.names = TRUE))



    ## 3) 数据框编辑
(data_iris <- rbind(data_iris, list(5.0, 3.6, 1.4, 0.2)))
(data_iris <- cbind(data_iris, Species = rep("setosa", 5)))
    # 增加数据集的新属性变量/新字段/新元素，setosa山鸢尾
(data_iris$Species <- rep("setosa", 5))     ;     data_iris
    

    ## 数据框的删除
data_iris[, -1]     
data_iris[-1, ]     # 删除第一行

    ## 数据框列名的编辑
names(data_iris)    
    # 查看数据框的“列名” ；注意，不是“行名”
names(data_iris)[1] <- "sepal.length"            ;   names(data_iris) 
rownames(data_iris) <- c("one","two","three","four", "five")     ;   data_iris
names(data_iris) <- c("x1", "x2", "x3", "x4")    ;   names(data_iris)







    

### 7. 因子(*)：类别 + 有序
    ## 1) 创建因子
    # 离散型变量，往往用于“分类、或计数”，需要借助因子对象来分析计算
    # 因子，可简单视为“附加了额外信息的[向量]”，分为“类别 + 有序”
(ff <- factor(substring("statistics", 1:10, 1:10), levels = letters))  
    # 将文本/字符串statistics“逐个拆分”为单个字符、创建因子向量，水平为26个小写字母
(f <- factor(ff))       
ff[, drop = TRUE]       # 等价于 f <- factor(ff)

factor(letters[1:20], labels = "letter")  
    # 创建因子向量，“水平名称/标签”为letter
(z <- factor(LETTERS[7:1], ordered = TRUE)) 
   

factor(1:4)
factor(1:4,levels=1:2)         #不要混淆因子长度和水平值
factor(c((1:4),(4:1)),labels=c("A","B","C","D"))       
    # labels：因子水平的标签，用数字或字母、无本质区别


    ## 创建“水平/level反复重复”的因子：gl(n, k, length)
gl(3, 3)              
gl(2, 3, labels = c("TRUE","FALSE")) 
    # 生成水平为“TRUE”和“FALSE”，每个水平重复3次的因子序列
gl(2, 1, 10) ##gl(因子数,重复次数,总长度)             
gl(2, 2, 10)      
gl(3, 3, ordered = TRUE)  
    # 生成水平数为3，每个水平重复3次的有序因子序列


    ## 2) 水平的频数统计，因子存储方式
status <- c("Poor", "Improved", "Excellent", "Excellent", "Poor", "Excellent")  
(status.factor <- factor(status, ordered = TRUE))   
    # 创建有序因子序列，按英文首字母、排序因子水平
levels(status.factor)        
table(status.factor)           
    

class(status.factor)          # 查看“数据对象的类型”
mode(status.factor)           
typeof(status.factor)         # 因子是按“整数”存储的，仅仅是“计数”分类的类别
as.numeric(status.factor)    









### 8. 表达式与公式
    ## 1) 表达式
f <- expression(sin(x1)+x2^2)       
    # 创建“不求值的表达式”，自变量、无须事先定义
f
x1 <- 12   ;  x2 <- 3.5     
eval(f)  #求表达式的值                   
D(f, "x1")      #求偏导            
D(f, "x2")


    ## 2) 公式
set.seed(12345)             # 设置随机数的种子数
p1 <- rnorm(100)            
p2 <- runif(100)
model.lm <- lm(p2~p1+I(p1^2)+I(p1^3))      
    # 多项式拟合时：二次以上的项，放入“ I() ”中
summary(model.lm)












#########################################################
            ######     Section 3： 对象的运算   ######


### 1. 数据对象类型转换
    ## 1) 类型判断
(M <- matrix(1:12,nrow=3,ncol=4))
mode(M)         # 模式：基本数据类型为“数值型”
class(M)        # 类：构造的对象类型为“矩阵”
typeof(M)       # 类型：细化数据类型为“整型”
is.matrix(M)    # 判断数据对象类型
is.numeric(M)



    ## 2) 类型转换
M.vec <- as.vector(M)    # 对象类型转换
M.vec
M.frame <- as.data.frame(M)
M.frame                  
    # 默认：行是“观测点”，列为“元素/变量/字段/组件名”


ff1 <- factor(c(49,81))
ff1
as.numeric(ff1)     # 因子水平“数值标识”，只是分类或计数的代号、不是真正的数值
as.numeric(as.character(ff1))   
    

ff2 <- factor(c("Shim", "Taylor", "Engel"))
ff2                  # 因子水平为“字符标识”时，按英文字母排序
as.numeric(ff2)      

methods(as)          # 更多类型的转换函数
methods(is)








### 2. 运算符 (三种：数学、比较、逻辑，“数/比/逻”)
    ## 1) 算术运算
(x <- c(15,16) %% 10)      # %% (模module运算：求余数)
    # 其他常见运算符：“ +  -  *  /  ^ ”
(y <- c(15,45) %/% 4)      # %/% (整除：除法的整数部分)
(x = pi*1:3^2)        
    

y <- matrix(c(1:9),ncol=3)
z <- matrix(c(11:19),ncol=3)
z[lower.tri(z)] <- 0
z
y*z                        # “矩阵对应元素”相乘：Hadmad积
y %*% z                    # 矩阵普通乘法：%*%
kronecker(y,z)           
    # 矩阵的“kronecker积”乘法
    # 若y为(m × n)维，z为(p × q)维，则新矩阵维度：(mp × nq)



    ## 2) 比较运算符
M <- c("A","B")
m <- c("a","b")
M==m                             
    # 单个元素比较；类似的，“>”、“>=”、"<"、"<="、“!=”
identical(M,m)                   # 对象整体比较
 

identical(y,z)
all.equal(y,z)      



    ## 3) 逻辑运算符“与、或、非”：&、|、!       
    ## 异或运算函数：xor(x, y)








### 3. 运算函数
    ## 1) 向量运算函数
x <- c(1,5,4,7,9)
sum(x)
mean(x)
sd(x)
median(x)
sort(x)        # 从小到大、排序
rev(x)         # 逆序
order(x)      
   

append(x, 2:3, after=2)         
    # 在x的“指定下标位置”处、添加新的向量元素2:3

x <- runif(100,0,20)
y <- runif(100,0,20)
x > y              # 得到比较的逻辑结果 
sum(x > y)         
   



    ## 2) 矩阵运算函数
(A <- matrix(1:9,ncol=3))
t(A)           # Transpose：普通“矩阵转置”
aperm(A,c(2,1))                 # 数组"维度转换"函数，效果同上

(A <- matrix(sample(1:100, 16), ncol=4))
solve(A)       # 方阵“求逆”；solve(a, b)，可解线性方程组“ax = b”

nrow(A)        # 求矩阵行数
ncol(A)

B <- matrix(1:8,ncol=4)  ;  B
(C <- matrix(8:1,ncol=4))  
rbind(B,C)          # rbind()：纵向按行合并
cbind(B,C)         





    ## 3) apply函数族 (避免代码重复操作，数值分析批量运算)
    ## a) apply函数(主要用于“矩阵”：apply(x, d, g))
(x <- matrix(1:20, ncol = 4)) 
apply(x, 1, mean)      # 计算各行的均值
apply(x, 2, sd)        

(x <- runif(10,-1,1))
(y <- rnorm(10,0.5,1))
(xy <- cbind(x,y))
class(xy)
apply(xy,1,sum)      # 对矩阵的行，按行求和
apply(xy,2,mean)     


    ## b) tapply函数 ( 用于“依因子对象分类”的“向量”：tapply(x, f, g) )
f1 <- factor(rep(1:4,length=14),levels=1:5,labels=c("A","B","C","D","E"))
    # 产生长度为14的因子对象，5个因子水平的标签、设为ABCDE
f1
(x2 <- c(1:14))
tapply(x2,f1,sum)       
aggregate(x2, by=list(f1),sum)                 
by(x2, f1, sum)                                
    # aggregate()、by()：可将tapply()函数对象为向量的限制，扩展到数据框
tapply(x2,f1,sum,simplify=FALSE)               # 返回一个列表



    ## c) lapply函数 (主要对“列表/数据框”对象、进行运算)
(L1 <- list(a=1:20, b=runif(30,-2,5), d=matrix(c(1:20),ncol=4)))
lapply(L1,quantile)    
    # 对列表的“各个元素/字段/组件”，分别求分位数函数运算 (矩阵也是一种向量)


    ## d) sapply函数 (lapply的特殊形式)
sapply(L1,quantile,simplify=FALSE,use.names=FALSE)   # 返回一个列表
sapply(L1,quantile,simplify=TRUE,use.names=FALSE)    

(L2 <- list(c("a", "b", "c"), c("A", "B", "C")))
sapply(L2, paste, 1:3, simplify = TRUE) 
    # 列表list中的每个元素、与数字1-3连接，输出结果为矩阵
sapply(L2, paste, 1:3, simplify = F)
    














#########################################################
######     Section 4：常用命令   ######

 
### 1. 工作目录与R内存
    ##  1) 设置工作路径
getwd()
setwd('I:/R learning/3 Finance with R')             # 斜杠
setwd('I:\\R learning\\3 Finance with R')           # 双反斜杠

    ## 2) R内存
memory.size(NA)
memory.limit()
memory.size(FALSE)
memory.size(TRUE)
memory.size(4095)        # 查看与增大工作内存





### 2. 加载与保存
    ## 1) R包
library(quantmod)       # 加载quantmod的包
require(quantmod)       # 同上
search()                # 查看当前空间中已存在的包


    ## 2) R对象
(x <- rnorm(10))
(y <- matrix(1:20, nrow=5))
(z <- paste("x", 1:10, sep=''))
ls()                # 查看当前空间中已存在的对象
save.image()        # 保存工作空间所有对象，生成“ .RData”文件
save(x,y,file="S.RData")
    # 仅保存部分“指定的对象”
load(file="S.RData")







### 3. 显示命令
head(iris)
tail(iris)
library(car)
some(iris)                # 显示“任意一些行”

D <- seq(1:3)
D
print(D)
(D <- seq(1:3))           
    # 显示全部，三种方式：直接用“对象名称”、“print( )”、“(对象)”

E1 <-3.1415926535
E2 <-3.1415926535
(E1.r <- round(E1,digits=4))            # 四舍五入，小数点保留四位
E1.r*1000000
options(digits=4)    ;    E2            # 显示四位数字，但未作四舍五入
E2*1000000





### 4.挂接命令
df <- data.frame(name=c("ZhangSan","XiaoHong","LiSi","XiaoLan"),
                 sex=c("M","F","M","F"),age =c(20,21,19,20),weight=c(110,90,128,102))
attach(df)             # 将“数据框/列表中的变量/元素”、直接“挂接到内存”
mean(age)              
    # 直接调用元素/字段名 (不再需用数据框/列表名引用)，作为对象来运算
detach(df)
mean(df$age)

library(quantreg)
detach("package:quantreg")        
    # 去掉挂接、释放内存，同时避免“不同包、相同函数的冲突”







