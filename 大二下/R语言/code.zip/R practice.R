# 实践 1 (最初几步：向量与抽样***)
x = 1:100        # 把1,2,3,...,100整数向量、赋值到x
(x = 1:100)      # 同上，只不过显示出来
sample(x,20)    
    # 从向量x中、不放回的随机抽取20个值，作为样本
set.seed(12345)    ;   sample(1:1000,15)     
    # 先设随机种子、再抽样，同样的随机种子、将得到同一组的随机数
sample(1:1000,15) 

z = sample(1:20000, 1000)
    # 从1,2,3,...,20000个数中，随机不放回的抽取1000个值、作为样本
z[1:10]          # 方括号中数字，为向量z的下标索引
y = c(1,3,7,3,4,29)    
    # c()：为连接concatenate函数，组合向量、或列表
z[y]             # 以y为下标的“z的元素值”
              
(z=sample(x,100,rep=T))          
    # 有放回的、从x中抽取100个值，作为样本
(z1= unique(z))        # 只保留唯一值的不同元素
length(z1)             # z中不同元素的个数
(xz = setdiff(x,z))    # 集合差：x和z间的不同元素(即z的“补集”)
sort(union(xz,z))      # 对“xz和z的并集(即全部的x)”的元素，从小到大排序
setequal(union(xz,z),x)   # 检查“xz和z的并”的元素，是否与x一样
intersect(1:10, 7:50)     # 两个数据的交集

sample(1:100, 20, prob=1:100)    
    # 从1:100中抽20个数，各数目抽到的"概率权重"、与1:100成比例





# 实践 2  (R的对象类型*:【向矩列框】)
(x = pi*(1:3)^2)
(x = pi*1:3^2)      # 向量生成运算符“ : ”的优先级，高于乘法运算*、但低于幂运算^

(z = hist(Nile))
class(z)       # 查看x的类型
    # “matrix、列表、data.frame”等对象在Rstudio的data中，向量元素值存在value中
mode(z)
typeof(z)      # x的更细的type
    ### class():类，In R 'every object' has a mode and a class    
    ### mode，是R存诸对象的模式；class 的概念是沿袭面向对象编程的概念而来，是一个更抽象的概念
    ### mode()：模式，常见的有"numeric", "character", "logical","complex", "raw","list", "expression", "name", "symbol" and "function".
    ### typeof和mode 相似，但比mode分得更精细，从精细度上说：typeof  > class > mode


   # cars的type
names(cars)    # cars数据中的变量名
summary(cars)  # cars数据的“汇总”
str(cars)      # 也是汇总，结构
head(cars)     # cars数据的头6行数据，与cars[1:6]等效
tail(cars)     # cars数据的最后6行数据
rownames(cars)      # rownames()：行名字
attributes(cars)    # cars的一些属性信息
class(dist~speed)   # 公式形式：“~”的左边、应变量，“~”的右边、自变量
plot(dist~speed,cars)        # plot(y~x)：两个变量的散点图
plot(cars$speed,cars$dist)   # plot(x, y)：同上





# 实践 3 (向量/序列***)
(z = seq(-1, 10, length=100))   
    # （-1, 10)间，等间隔的生成“100个数”的等差序列
(z = seq(10, -1, by = -0.1))          
    # 从10到-1间，生成“间隔/步长为-0.1”的等差序列
(y <- 1:11)           # “等差序列”向量：若步长为1，可直接用“ : ”实现
(y1 <- 3*2^(1:11))    # 将等差数列、放在指数上，即生成“等比数列”
(x = rep(1:3, 3))           # replicate：(1:3)、重复3次
(x = rep(1:3, each=3)) 
(x = rep(3:5, 1:3))         # 序列3:5、对应的元素，分别重复1、2、3次
(x = rep(c(1, 10), c(3, 5))) 
    # “对应的元素”1、10，分别重复3次、5次
(w = c(1, 3, x, z))         
    # concatenate连接函数c()：把“非规则的数据”（包括向量)、组合/连接成一个向量
w[2:8]

    ## 向量的加法、乘法与除法
x =rep(1, 10) 
z = 1:3 
x+z            # 若长度不同，短向量元素、将重复使用
x*z            # 向量乘法：对应的元素、直接相乘
x/z            # 向量除法：对应的元素、直接相除，短向量、将循环补齐
rev(z)         # 颠倒元素次序

    ## 字符向量
(z =c("no cat", "has", "nine", "tails"))      
    # “连接”生成字符向量
paste("no cat", "has", "nine", "tails")       
    # “粘接”文字字符、或数字
z[1] == "no cat"       # 双等号，为"逻辑等式"比较判断
class(z)               # 数据对象类型、为“字符型”，而非“vector”
mode(z)
typeof(z)



    ## 向量元素的引用与去除
z = 1:5 
z[7] = 8
z          # NA, 为缺失值
rnorm(10)[c(2,5)]        
    # 随机序列rnorm(10)中的第2个、第5个元素
x = NULL
x
x[c(1, 3, 5)] = 1:3
x
x[-c(1, 3)]            # “去掉”第1个、第3个元素
x[c(-1, -3)]  

(z = sample(1:100, 10)) 
which.max(z)                 
    # 给出“最大值的下标”
which(z==max(z))       # 同上
which(z >= mean(z))          
    # 找出满足条件“z >= mean(z)”的那些元素的下标
z[which(z >= mean(z))]
    # 输出满足逻辑索引条件“ z >= mean(z) ”的元素
z[ z >= mean(z) ]            
    # 同上等价，“逻辑索引”：返回逻辑值为真的那些向量元素

(x = sample(-50:50, 20)) 
all(x>0)   ;   all(x!=0)  ;  any(x>0)    
    # “逻辑符号”的应用
    # any()：至少有一个“逻辑值结果”是真的，结果就是真的
x[x>0]           # 输出满足“ 逻辑索引条件 x>0 ”的向量元素
(1:12)[x>0]      
    # 查找前12个元素中，满足“ x>0 ”的向量元素的下标
x[(1:12)[x>0]] 
    # 查找前12个元素中，满足“ x>0 ”的向量元素
diff(x)           # 一阶差分
diff(x, lag=2)               # “2期滞后”差分
    # 对数值向量或矩阵、或时序，base包中的滞后差分diff()、均适用
diff(x, differences=2)       # “2阶”差分





# 实践 4   (向量的描述性统计、算术、排序、累积运算***)
(x <- round(runif(20,1,1000), digits = 2))     # 四舍五入，保留小数点2位
    ###  “d/p/q/r + 分布名称”，密/概/分/数 
    ###  离散型：binom(二项)，nbinom(负二项)，geom(几何)，hyper(超几何)，pois(泊松)
    ###  连续型：unif(均匀)，norm(正态)，chisq(卡方)，t(t)，f(F)，gamma(伽玛)，exp(指数)，beta(β)，triangle(三角)
    ###  更多分布函数： https://cran.r-project.org/web/views/Distributions.html
summary(x)    # 汇总
min(x)  ;  max(x)        # 极值区间，与range(x)类似
mean(x) ; median(x)      # 均值,中位数
var(x)        # 方差
sd(x) ; sqrt(var(x))     # 标准差,即方差的平方根
fivenum(x)    # 五数汇总（计算规则，基于中位数）
quantile(x)   # 四分位数（计算规则，完全基于分位数概念）
quantile(x,c(0, .33, .66, 1))      
    # 三分位数：指定“分位百分点”
mad(x)        # median average distance

round(x)      # 等价于{ round(x,0) },四舍五入、取整
floor(x)      # 向下取整
ceiling(x)    # 向上取整

(x <- round(runif(10,0,20), digits = 2)) 
sort(x) 
sort(x,decreasing = T)   # 简写“ sort(x,dec = T) ”，降序排列的x
rank(x)       # 秩，向量“x中对应元素”的排名(从小到大)
order(x)                 
    # 升序排列的元素“在x中的下标”，即“sort(x)中对应排名的元素”、在向量x中的位置
order(x,decreasing = T)  # 降序排列的元素“在x中的下标”
x[order(x)]   
    # 与｛ sort(x) ｝相同
sum(x)        # 元素求和
length(x)     # 向量元素的个数

cumsum(x)     
    # 累积和，与x等长
cummax(x)  ; cummin(x)     # 累积最大值、累积最小值
prod(x)
cumprod(x)    # 累积积
cor(x,sin(x/20))           # 线性相关系数



### 自编补充案例： 某工程项目进度总工期的随机模拟 (亦可用于作业成本法的总成本估算)
    # 假设某项目关键路径上共有“8个作业单元”，时间参数分别服从正态分布(1、7、8)、三角分布(2~6) 
u1 <- rnorm(1000000, 10, 2)    
    # 假设作业单元1，作业时间服从N(10, 2^2)的正态分布
library(triangle)    # 三角分布的相关函数，在triangle包中
u2 <- rtriangle(1000000, 5, 33, 11)
    # 假设作业单元2，作业时间服从Tri(5, 33, 11)的三角形分布
    # 生成10^6个工期三角分布的随机数
u3 <- rtriangle(1000000, 7, 28, 10)
u4 <- rtriangle(1000000, 4, 10, 8.5)
u5 <- rtriangle(1000000, 6, 29, 9)
u6 <- rtriangle(1000000, 9, 41, 13)
u7 <- rnorm(1000000, 15, 3)
u8 <- rnorm(1000000, 6, 2)
alltime <- u1 + u2 + u3 + u4 + u5 + u6 + u7 + u8
mean(alltime)
sd(alltime)
hist(alltime)
plot(density(alltime))
quantile(alltime, 0.9)
quantile(alltime, 0.95)
quantile(alltime, 0.99)
abline(v=mean(alltime), lty=3)
abline(v=quantile(alltime, 0.95), lty=3, col=3)
abline(v=quantile(alltime, 0.99), lty=1, col=2)
text((mean(alltime)-1), 0.003, "mean = 105.5")
text((quantile(alltime, 0.95)+9), 0.013, "95%分位数 = 126.7", col=3)
text((quantile(alltime, 0.99)+15), 0.028, "99%分位数 = 135.7", col=2)






# 实践 5（因子水平、与字符向量）
a = factor(letters[c(1:10, 7:12)])  
    # 生成因子对象，其水平为：letters为小写字母的向量，LETTERS为大写字母
a
mode(a)
class(a)
typeof(a)   
    # 因子的值，本质上不是数字(数字、字符，都仅仅是编码)，而是对应着分类
a[3] = "w"      
    # 不能给因子水平(仅为“分类标识、数字编码”)赋值，它并不是字符！

a =as.character(a)            # “转换”成字符型
a[3] = "w"          # 可赋字符了
a                   # 字符向量
(a1 <- factor(a))   # 两种不同类型的数据

class(letters)
(a2 = letters[1:10])          # letters：R预定义的“含26个字母的字符向量”





# 实践 6（矩阵1**：矩阵创建、初等运算、转置与求逆）
(x = matrix(1:20, nrow=4, ncol=5))            
    # 矩阵的构造,默认“按列充值”
(x1 = matrix(1:20, 4, 5, byrow=T))   
    # 矩阵的构造,指定“按行排列”
t(x1)             # 转置“transpose”
t(x1[2:4, 2:4])

x = matrix(sample(1:100, 15), 3,5)
2*x 
x + 5      # 与标量数乘、相加
y = matrix(sample(1:100, 15), 5,3)
y
x + t(y)         # 同型矩阵相加
(z = x %*% y)      
    # 矩阵乘法：%*%
(w = kronecker(y,z))           
    # 矩阵的“kronecker积”乘法
    # 若y为(m × n)维，z为(p × q)维，则新矩阵维度：(mp × nq)

z1 = solve(z)   
    # solve(a, b)，可解方程组“ax = b”；b缺省时、默认为“单位阵”，可方阵“求逆”
(I = z1 %*% z)        # 得到单位矩阵，但浮点运算、得不到干净的0
(x = solve(z,1:3))
    # 解线性方程组: zx = b = 1:3





# 实践 7（矩阵2***：索引/筛选、对角/三角阵、固定维度运算）
(x = matrix(rnorm(24,1,2), 4, 6))
nrow(x) ; ncol(x) ; dim(x)       # 行/列数，维数

    ### 子矩阵的筛选
x[c(2, 1), ]         # 第2行与第1行
x[ , c(1, 3) ]       # 第1列与第3列
(y = x[x[ , 1]>0, 3])         
    # 第1列大于0的元素下标所应对的行、所索引的第3列元素
sum(x[ , 1]>0)         
    # “第1列大于0的元素”的个数；“ x[ , 1]>0 ”比较表达式自身，得到的是一系列逻辑值
    # 统计“满足逻辑索引条件的元素”的个数
sum(x[x[ , 1]>0, 3])   
    # “第1列大于0的元素下标所应对的行、所索引的第3列元素”的求和
x[-2 , -c(1, 3)]        
    # 去掉x的第2行、去掉x的第1列与第3列
x[x[ , 1]>0 & x[ , 3]<1, 1]         
    # 逻辑索引：“第1列大于0、且第3列小于1”的第1列元素
x[x[ , 2]>2 | x[ , 1]<0.51, 5]     
    # “第2列大于2、或者第1列小于0.51”的元素下标、所索引第5列元素
x[!x[ , 2]<0.51, 1]     
    # "第2列 >= 0.51的元素下标”、所索引的第1列元素
    # 逻辑运算符，与或非：&、|、!

    ## 对角线与对角阵：Diagonals
diag(x)          # x的对角线元素
diag(1:5)        # 以“1:5向量为对角线元素”的对角阵
diag(5)          # 5维单位阵

    # 求三角阵：triangle
x[lower.tri(x)]=0   ;   x        # 将下三角元素赋0、得到上三角矩阵
    # lower.tri(x)，返回的是“与x同维的逻辑值矩阵”
x[upper.tri(x)]=0   ;   x        # 将下三角元素赋0、得到下三角矩阵

    ## 对矩阵的行或列、作运算
apply(x, 1, mean)       # 对x的行(第1维)、求均值
apply(x, 2, var)        # 对x的列(第2维)、求方差





# 实践 8  (高维数组，略讲)
x = array(runif(24), c(4, 3, 2)) 
x         # 构造行、列、层分别为“4×3×2”的3维数组
is.matrix(x)             # 判断是否矩阵
dim(x)                   # 得到维数(4, 3, 2)：行、列、层

    ## 三维数组的部分截取
y <- x[1, , ]
y                        # 默认“按列充值”
dim(y)
is.matrix(x[1, , ])      # 三维数组的部分，是矩阵

    ## 对数组的某一维或部分维，作运算
(x = array(1:24, c(4, 3, 2))) 
x[c(1, 3), , ]           # 截取部分三维数组(2, 3, 2)
apply(x, 1, mean)        # 对第1维、求均值：(1+5+9+13+17+21)/6=11
apply(x, 1:2, sum)       # 对部分维（固定第1维与第2维）、求和
apply(x,c(1, 3), prod)   # 对部分维（固定第1维与第3维）、求乘积





# 实践 9  (列表list***：列表元素的索引/访问)
    # list，可是多种不同对象的“集合” (包括list本身)
z = list(1:3, Tom = c(1:2, a=list("R", letters[1:5]), w="hi!")) 
length(z)          # 列表元素/字段/组件的个数
z[[1]]
class(z[[1]])             # Lt[[下标，或"元素名"]]，双重中括号、取出的是“元素内容”
z[1] 
class(z[1])               # Lt[下标，或"元素名"]，单重中括号、取出的是“子列表”
z[2]
z["Tom"]           # 同上

z$Tom
    # “Lt$元素名”引用(此时元素名、不须加引号)，与Lt[["元素名"]]的“双重中括号”等价，取出的是元素内容
z$T                # 同上，元素名Tom的简写T
class(z$T)         # Tom，此处仍是一个list：由“不同对象”、组合Combine而成
z$T$a2 
    # 双重$引用
z$T[4]
    # 子列表z$T的第四个元素，结果同上
z$T$w





# 实践 10  (数据输入输出、数据框**)
x = scan()      # 从“屏幕输入”数据（可键入、粘贴、多行输入），空行后、enter回车
1.5 2.6 3.7 2.1 8.9 12 -1.2 -4
x
(x = c(1.5, 2.6, 3.7, 2.1, 8.9, 12, -1.2, -4))   
    # 连接concatenate/combine函数c()：生成“非规则”数据序列
    # 与上面，等价
x[5]

setwd("H:/R learning/Applied TS/my work")      
    # 设立"工作路径"，或setwd("H:\\R learning\\Applied TS\\my work")、也一样
    # 反斜杆“ \ ”是转义字符，故指定路径要用双反斜杠“ \\ ”、或斜杠“ / ”
w = read.table(file.choose(), header = T)      # 从“文件列表”中，选择有变量名的数据
(x = rnorm(20))
write(x, "E:/R learning/my work/test.txt")          # 把数据、写入指定文件（工作路径要对）
y = scan("E:/R learning/my work/test.txt") ; y      # 扫描“文件数据”、到y

    ### 读/写“txt、或csv文件”的数据：read.table()、 read.csv()
y = iris ; y[1:5]          # iris是R自带数据
write.table(y,"test.txt", row.names = F)  # 把数据写入文本文件
    # 若将“文件放工作路径下”，则可“省去路径名”
w = read.table("E:/R learning/my work/test.txt", header=T)   
    # 读入“有变量名抬头的数据”
str(w)      # 结构汇总
write.csv(y, "test.csv")  # 把数据写入csv数据文件
v = read.csv("E:/R learning/my work/test.csv")      ###  读入csv数据文件
str(v)      # 汇总

data = read.table("clipboard")            # 读入剪贴板的数据



    ### 数据框补充：创建数据框，每列数据类型可不同、但长度必须相同
data_iris <- data.frame(Sepal.Length = c(5.1, 4.9, 4.7, 4.6), 
                        Sepal.Width = c(3.5, 3.0, 3.2, 3.1), 
                        Petal.Length = c(1.4, 1.4, 1.3, 1.5),
                        Petal.Width = rep(0.2, 4))
    # 向量组成数据框
    # iris：鸢(yuan)尾花，Sepal花萼、Petal花瓣
data_iris
(data_matrix <- matrix(1:8, c(4, 2)))     # 创建一个矩阵
(data.frame(data_matrix))                 # 将矩阵转化为数据框


    ### 数据框索引
    ## 列索引
data_iris[, 1]                # 索引第一列
data_iris$Sepal.Length        # 按列的名称索引
data_iris["Sepal.Length"]     # 按列的名称索引

    ## 行索引
data_iris[1, ]        # 索引第一行
data_iris[1:3, ]      # 索引第一至三行

    ## 元素索引
data_iris[1, 1]                 # 索引第一列第一个元素
data_iris$Sepal.Length[1]       # 索引Sepal.Length列第一个元素
data_iris["Sepal.Length"][1]    # 索引Sepal.Length列第一个元素

    ## subset函数索引(**)
subset(data_iris, Sepal.Length < 5)     # 按逻辑条件索引行  
    ## sqldf函数索引(略)
library(sqldf)
mtcars      # A data frame of R with 32 observations on 11 variables
(newdf <- sqldf("select * from mtcars where carb = 1 order by mpg", row.names = TRUE))



    ### 数据框编辑
(data_iris <- rbind(data_iris, list(5.0, 3.6, 1.4, 0.2)))
    # 增加新的样本数据
(data_iris <- cbind(data_iris, Species = rep("setosa", 5)))
    # 增加数据集的新属性变量/新字段/新元素，setosa山鸢尾

    ## 数据框的删除
data_iris[, -1]  # 删除第一列
data_iris[-1, ]  # 删除第一行

    ## 数据框列名的编辑
names(data_iris)  # 查看数据框的列名
names(data_iris)[1] <- "sepal.length"  
    # 采用赋值语句，将数据框第一列列名改为sepal.length
names(data_iris)  # 查看修改后数据框的列名





# 实践 11 (缺失值、重复行查找与删除，数据的附加/合并***)
airquality               # “有缺失值的”R自带数据
complete.cases(airquality)             
    # complete.cases()：判断“每行”有/无缺失值，判断结果为逻辑值 T/F
which(complete.cases(airquality)==F)   
    # 查找"有缺失值的行号"
sum(complete.cases(airquality))        # 求和“完整观测值的个数”
na.omit(airquality)      
    # na.omit()：删除缺失值

    
    ## 重复行的查找与删除
(x = rbind(5:10, runif(6), runif(6), 5:10, 11:16))
# (x = sample(1:20,20, rep=T))
duplicated(x)
    # 若x为矩阵，对行查重、返回逻辑值T或F (1或0)
    # 若x为向量，则对元素查重
x[!duplicated(x), ]      
    # 逻辑索引：去掉“矩阵重复的行”
unique(x)      
    # unique()：若x为矩阵，对行、作唯一运算；功效同上


    ## 附加数据append()
x = 11:20 
x[12]=3
x
(x1 = append(x, c(77,88, 99), after = 5))       
    # 在x的“指定下标位置”处、添加新的向量元素c(77,88, 99)


    ## 横/竖合并数据、rbind/cbind()
cbind(1:5, rnorm(5))     
    # 按列、横向合并数据
rbind(1:5, rnorm(5))     
    # 按行、竖向合并数据




# 实践 12  (简单运算)
pi*10^2            # 只计算、不存储
x = pi*10^2        # 计算、并存储在x中
x  
print(x)           # 与 x 等效
(x = pi*10^2)      # 赋值带打印
print(x, digit=12)    # 输出x的12位数字

pi*(1:10)^2     
    # 可对向量、求指数幂
pi^(1:5)          
    # 指数，也可以是向量
(x = pi*1:3^2)        
    # 生成向量运算符“ : ”的优先级，高于乘法运算*、但低于幂运算^
    # 生成向量运算符“ : ”的优先级,也高于一般“加减乘除的四则运算”





# 实践 13  (矩阵与向量之间的运算*)
(x = matrix(1:20, 5, 4)) 
sweep(x, 1, 1:5, "*")   
    # 把"向量1:5的每个元素"、乘到“x的每一行”
sweep(x, 2, 1:4, "+")    
    # 把“向量1:4的每个元素”、加到“x的每一列”

x*1:5       # 与sweep(x, 1, 1:5, "*")，等价
x + 1:5     # 自动匹配维度：与sweep(x, 1, 1:5, "+")，等价
x + 1:4     # 自动匹配维度：与sweep(x, 2, 1:4, "+")，等价

    ## 将矩阵x标准化
(x = matrix(sample(1:100, 24), 6, 4))
(x1 = scale(x))         
    # 正常“按列”标准化：（每个元素 - 每列均值）/每列标准差
(x2 = scale(x, scale = F))      # 按列标准化时、不除标准差
(x3 = scale(x, center = F))     # 按列标准化时、不减列均值





# 实践 14  (依分类因子，计算频数、形成表格)
library(MASS)            # 加载软件包MASS
quine                    # MASS所带的数据
attach(quine)            # 把数据变量的名字、直接放入内存
head(quine)
sapply(quine, mode)
sapply(quine, class)
sapply(quine, typeof)


   ## 从该数据得到的各种表格
table(Age)                          # 依一个分类因子Age、分组数据并统计频数
table(Sex, Age)                     # 依两个分类因子，计算频数、制列联表
(tab = xtabs(~Sex + Age, quine))     
    # 同上，公式法表达：依两个分类因子，计算频数、制列联表
unclass(tab)
tapply(Days, Age, mean)             # 计算“依Age分类的分组数据”的变量Days的mean
tapply(Days, list(Sex, Age), mean)
    # 计算“依两个分类因子 (组合成list)、交叉分组数据”的变量Days的mean
detach(quine)            # attach的逆运算





# 实践 15  (条形图、制表)
x = scan()     # 30个顾客，在“5个品牌”（即分类因子）中的挑选结果
3 3 3 4 1 4 2 1 3 2 5 3 1 2 5 2 3 4 2 2 5 3 1 4 2 2 4 3 5 2

barplot(x)     # 不合要求的条形图

table(x)       # 依分类因子，“计算频数”制表
barplot(table(x))                 # 正确的图
p = table(x)/length(x)            # 计算频数比例 
(p = round(p, 2))
barplot(p)                        # 比例图





# 实践 16  (简单绘图**)
(x = rnorm(200))    # 产生200个标准正态随机数的数值向量
hist(x,col = "light blue")   
    # 直方图
rug(x)              # 在直方图下，加上实际点分布值
stem(x)             # 茎叶图
plot(density(x))  
    # 输入参数、为“某函数的计算结果”：密度图 

    ## 两变量的散点图与回归线
x <- rnorm(500)   
y <- x + rnorm(500)           # 构造一个线性关系
plot(y~x)           # 散点图
plot(x,y)           # 同上
a <- lm(y~x)        # 线性回归
summary(a)          # 回归结果汇总
abline(a, col="red")          # 散点图上、附加“回归拟合线”

    ## 输出结果 
print("Hello World")
paste("x的最小值= ", min(x))  # “粘接”数字、字符

demo(graphics)    # 演示画图，点击enter、切换新图





# 实践 17（画图***）
x = seq(-3, 3, len=20)     # 在给定区间上，生成数值向量 
y = dnorm(x)        # 产生与向量x对应的标准正态分布“密度数据”（非概率）
(w = data.frame(x, y))                 # 合并x、y，生成数据框w

par(mfcol=c(2,2))        
    # 设置图形参数，准备画(2×2)个图的地方
plot(y~x, w, main="正度密度函数")
plot(y~x, w, type="l", main="正度密度函数")
plot(y~x, w, type="b", main="正度密度函数")      # 点、线结合，但不重叠
plot(y~x, w, type="o", main="正度密度函数")      # 点、线结合，且可重叠
par(mfcol=c(1,1))        # 将画布还原：取消par(mfcol=c(2,2))





# 实践18 (色彩、符号、图例等调节)
plot(1, 1, xlim=c(1, 7.5), ylim=c(0, 5), type="n")    # 绘制“主画布框架”，但先不绘图

    ## 在plot命令后，追加点、或线（lines函数）
points(1:7, rep(4.5, 7), cex=seq(1, 4, l=7), col=1:7, pch=0:6)
    # 在指定位置，添加“点符号0~6”
text(1:7, rep(3.5, 7), labels=paste(0:6, letters[1:7]), cex=seq(1, 4, l=7), col=1:7)
    # 在指定位置，添加“文字”；参数cex，指定广本或符号的“缩放比例”，默认为标准1

points(1:7, rep(2, 7), pch=(0:6)+7)     
    # 在指定位置，点出符号7~13
text((1:7)+0.25, rep(2, 7), paste((0:6)+7))           
    # 加符号文字号码说明
    # 符号的形状、大小、颜色、及其他画图选项的说明，可用"?par"查看

points(1:7, rep(1, 7), pch=(0:6)+14)     # 点出符号14~20
text((1:7)+0.25, rep(1, 7), paste((0:6)+14))         
    # 在指定位置，粘贴符号号码14~20





# 实践 19  (如何写函数**)
    ## 以下函数，按定义求n以内的素数(简单编程，效率不高)
ss = function(n=100) 
  { z=2;
for (i in 3:n)  {
  if(any(i %% 2:(i-1) == 0)==F) 
    # 对自然数i：除1与i自身外,其他“任何2:(i-1)间的整数”、均不能整除i (即余数不为0)
    # 向量化：对向量的每个元素，应用函数、或运算符
    # any()：至少有一个、是真的
  #  if(all(i %% 2:(i-1) != 0)==T)         # 与上述条件、等价，更易理解
    z=c(z,i)    }        # 每满足一次条件，则添加一个素数、至素数向量中
  return(z)     
  }
    

my.ss = fix(ss)          # 用来修改任何函数，或新编写一个函数
ss()           # 计算100以内的素数
ss(10000)      # 计算10000以内的素数
system.time(ss(10000))   # 计算执行ss(10000)所用时间





# 实践 20  { 复数运算(略)；求方程的根、函数极值** }
(2+4i)^-3.5+(2i+4.5)*(-1.7-2.3i)/(2.6-7i)*(-4+5i)   # 复数运算
(z <- complex(real=rnorm(10), imaginary = rnorm(10)))
    # 构造一个“10维复向量”，实部与虚部、均为10个标准正态分布样本点
complex(re=rnorm(10), im=rnorm(10))   # 简写形式
Re(z) ; Im(z) ; Mod(z) ; Arg(z)       # 实部，虚部，模，辐角

choose(3,2)          # 组合
factorial(6)         # 阶乘6!


    ## 方程求根:uniroot()
f = function(x) x^3-2*x-1     
    # “函数体”只有一行时，不用“ { } ”
uniroot(f, c(0,2))   # 迭代求根

    ## 求函数极值：optimize()
f = function(x) x^2+6*x+1   
    # 先定义“函数”表达式，此处不能用expression()
optimize(f, c(-4,4))        # 在区间(-4, 4)上、求极小值





# 实践 21  (回归：包含定量/定性变量***)
nrow(cars)  
ncol(cars)       # cars的行/列数
dim(cars)        # cars的维数
names(cars)      # cars中“对象的名字”
lm(dist~speed, data=cars)    
    # OLS回归：以dist为因变量、speed为自变量，数据框为cars

    ### cut()：将连续变量speed、切分为“区间分类变量qspeed”，四分位点、为“分割点”
cars$qspeed = cut(cars$speed, breaks=quantile(cars$speed), include.lowest = TRUE)
names(cars)      # 数据cars,多了一个变量
cars[3]          # 数据框的子框，与cars[,3]类似
class(cars[3])       # 数据框
cars$qspeed      # 直接提取第3个对象的值
class(cars$qspeed)   # 定性“分类变量”，因子对象（分类、或计数）
table(cars[3])       # 频数统计、列表
plot(dist~qspeed, data=cars)      # 点出“各因子水平下的箱线图”
plot(cars$qspeed, cars$dist)      # plot(f,y)：同上
(a=lm(dist~qspeed, data=cars))    
    # 拟合线性回归：4个区间变量、须引入3个虚拟变量
(b=lm(dist~qspeed + speed, data=cars))
summary(a)       # 回归结果(含一些检验)
summary(b)       # speed的定性与定量信息，存在严重的共线性问题








### simple test
#1 6 12 24 ...... 3072 
3*2^(1:10)
#  2/3 2 6 ...... 486
2*3^(-1:5)


# 2
x <- 3:11
y <- seq(11, 3, by = -2)
rep(y[2:4], x[1:3])


# 3
(f <- factor(rep(c(2,7),c(2,4))))
x <- 5:10
tapply(x, f, mean)



