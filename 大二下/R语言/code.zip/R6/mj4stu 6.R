############   第六讲  金融波动模型   ###########



              ##### section 6.1：GARCH类模型



### 0. 初始化
setwd('D:\\大学\\大二到大四\\大二下\\R语言\\R6')
rm(list=ls())


### 1. 加载包
library(fGarch)
library(timeSeries)                               
library(tseries) 
library(xts)





### 2. 模拟一元ARCH时间序列模型 (略)
    ## 1) 仿真 ARCH(1) 模型
set.seed(12345)
spec_1 <- garchSpec(model=list(omega=0.01, alpha=0.85, beta=0))
simdata_1 <- garchSim(spec_1, n=200, extended=TRUE)
class(simdata_1)
plot(simdata_1)
par(mfrow=c(1,3))
acf(simdata_1$eps, main='(a) 残差序列', xlab='滞后期')
acf(simdata_1$garch, main='(b) 模拟数据', xlab='滞后期')
acf(simdata_1$garch^2, main='(c) 模拟数据平方', xlab='滞后期')
par(mfrow=c(1,1))


    ## 2) ARCH 效应测试
library(FinTS)
ArchTest(x=simdata_1$garch, lags=12)
ArchTest(x=simdata_1$eps, lags=12)





### 3. 模拟一元GARCH时间序列模型 (略讲)
    ## 1) 模拟 GARCH(1,1) 模型
set.seed(12345)
spec_2 <- garchSpec(model=list(omega=0.01, alpha=0.85, beta=0.1))
simdata_2 <- garchSim(spec_2, n=200, extended=TRUE)
# extended为真时，输出3列时序，否则只输出一元时序
class(simdata_2)
par(mfrow=c(1,3))
plot(c(simdata_2$eps), type='l', xlab='天', ylab='', main='(a) 残差序列')
plot(c(simdata_2$garch), type='l', xlab='天', ylab='', main='(b) 模拟数据')
plot(c(simdata_2$sigma), type='l', xlab='天', ylab='', main='(c) 条件标准差')
par(mfrow=c(1,1))

par(mfrow=c(1,3))
acf(simdata_2$eps, xlab='滞后期', main='(a) 残差序列')
acf(simdata_2$garch, xlab='滞后期', main='(b) 模拟数据')
acf(simdata_2$garch^2, xlab='滞后期', main='(c) 模拟数据平方')
par(mfrow=c(1,1))








### 4. 案例分析 6-4：恒生指数月收益率的GARCH建模
    ### 单变量Garch建模：fGarch包，rugarch包
    ## 1) 读入数据
    ## a) 实时在线、读取数据
library(quantmod)                                           
getSymbols('HSI', from='1989-12-01', to='2013-11-29')      
dim(HSI)                                                   
names(HSI)                                                  
head(HSI)    ;    tail(HSI)
chartSeries(HSI, theme='white')  #画出价格与交易的时序k线图                          


    ## b) 从硬盘、读取数据
HSI <- read.table('HSI.txt')                                
head(HSI)  ;   dim(HSI)  ;   names(HSI)  ;   class(HSI)
HSI <- as.xts(HSI)                                          
class(HSI)                                                  
chartSeries(HSI, theme='white')                             

    ## 2) 计算百分比对数收益率
ptd.HSI <- HSI$HSI.Adjusted  #提取日收盘价                               
ptd.HSI <- na.omit(ptd.HSI)                                
rtd.HSI <- diff(log(ptd.HSI))*100                           
rtd.HSI <- rtd.HSI[-1,]                                     
plot(rtd.HSI) #画出日收益序列的时序图：波动大，噪音多，考虑低频数据                                              

head(to.monthly(HSI))    ;     tail(to.monthly(HSI))
ptm.HSI <- to.monthly(HSI)$HSI.Adjusted                    
rtm.HSI <- diff(log(ptm.HSI))*100                          
rtm.HSI <- rtm.HSI[-1,]                                    
plot(rtm.HSI)                                              
detach(package:quantmod)


    ## 3) 划分“样本外/样本内”子样本(***) + ARCH效应检验?
##大部分点用来建模，少部分留下做预测
class(rtm.HSI)  ;  dim(rtm.HSI)  ;  head(rtm.HSI)  ;  tail(rtm.HSI)
###设置样本外标识，提取'rts.HSI'时间索引index中的第4-8个字符（因为十一月的时候多一个字符）
    ##substr()子字符提取；'%in%'是值匹配运算，返回逻辑值/向量；这里只要是2013年的的数据将返回T，认为是样本外数据
    ##将' '替换为''，把空格去掉
outsample <- gsub(' ', '', substr(index(rtm.HSI), 4, 8)) %in% '2013'   
insample <- !outsample      #！是逻辑非，不是2013年的数据都是样本内数据                         
(rtm.insample <- rtm.HSI[insample])                         
(rtm.outsample <- rtm.HSI[outsample])

Box.test(rtm.insample, lag=12, type='Ljung-Box')     #'Ljung-Box'序列相关检验：月度收益序列不存在自相关
Box.test(rtm.insample^2, lag=12, type='Ljung-Box')   #'Ljung-Box'序列相关检验：月度收益序列的平方存在自相关
##平方数据的p-value为0.0014，很小，拒绝不是自相关的原假设，所以自相关
FinTS::ArchTest(x=rtm.insample, lags=12)   #存在显著的arch效应                    


    ## 4) 模型初步定阶
epst <- rtm.insample - mean(rtm.insample)   #均值调整，又称de-mean、，去均值，得到残差                   
par(mfrow=c(1,2))
acf(as.numeric(epst)^2, lag.max=20, main='平方序列')
pacf(as.numeric(epst)^2, lag.max=20, main='平方序列')         
#利用PACF函数确定"Arch部分的最优后滞阶数q*"，q<=3

    ## 5) 建立GARCH类模型
library(fGarch)
GARCH.model_1 <- garchFit(~garch(1,1), data=rtm.insample, trace=FALSE)#Garch(1,1)-N
#允许均值方程扰动项汉ARMA(2,1)结构，如Arma(2,1)~Aparch(1,1)模型
GARCH.model_2 <- garchFit(~garch(2,1), data=rtm.insample, trace=FALSE)#Garch(2,1)-N                    
GARCH.model_3 <- garchFit(~garch(1,1), data=rtm.insample, cond.dist='std', trace=FALSE) #Garch(1,1)-t  
GARCH.model_4 <- garchFit(~garch(1,1), data=rtm.insample, cond.dist='sstd', trace=FALSE) #Garch(1,1)-st 
GARCH.model_5 <- garchFit(~garch(1,1), data=rtm.insample, cond.dist='ged', trace=FALSE)  #-ged模型
GARCH.model_6 <- garchFit(~garch(1,1), data=rtm.insample, cond.dist='sged', trace=FALSE) #-sged模型 
#拟合garch模型，条件分布“偏斜广义误差分布segd

summary(GARCH.model_1)
summary(GARCH.model_2)      


plot(GARCH.model_1)        

    ## 6) 提取GARCH类模型信息
slotNames(GARCH.model_1)     
mode(GARCH.model_1)    
class(GARCH.model_1) 
typeof(GARCH.model_1)#S语言第四代数据对象
(vol_1 <- fBasics::volatility(GARCH.model_1))  
#提取波动率sigma(t)
(GARCH.model_1@sigma.t) #访问第四代对象的元素等用@代替$
#提取样本内r(t)拟合值
(GARCH.model_1@fitted)
sres_1 <- residuals(GARCH.model_1, standardize=TRUE)          
vol_1.ts <- ts(vol_1, frequency=12, start=c(1990, 1))         
sres_1.ts <- ts(sres_1, frequency=12, start=c(1990, 1))
par(mfcol=c(2,1))
plot(vol_1.ts, xlab='年', ylab='波动率sigma(t)')
plot(sres_1.ts, xlab='年', ylab='标准化残差')

    ## 7) 模型检验
par(mfrow=c(2,2))
acf(sres_1, lag=24)
pacf(sres_1, lag=24)                 
acf(sres_1^2, lag=24)         
pacf(sres_1^2, lag=24)
FinTS::ArchTest(x=sres_1, lags=12)  

par(mfrow=c(1,1))
qqnorm(sres_1)
qqline(sres_1)

    ## 8) 模型预测与比较
#对fgarch拟合结果向前预测11期，但不画图
pred.model_1 <- predict(GARCH.model_1, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)
pred.model_2 <- predict(GARCH.model_2, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)
pred.model_3 <- predict(GARCH.model_3, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)
pred.model_4 <- predict(GARCH.model_4, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)
pred.model_5 <- predict(GARCH.model_5, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)
pred.model_6 <- predict(GARCH.model_6, n.ahead = 11, trace = FALSE, mse = 'cond', plot=FALSE)

names(pred.model_1)
#提取预测结果的标准差
predVol_1 <- pred.model_1$standardDeviation       
predVol_2 <- pred.model_2$standardDeviation
predVol_3 <- pred.model_3$standardDeviation
predVol_4 <- pred.model_4$standardDeviation
predVol_5 <- pred.model_5$standardDeviation
predVol_6 <- pred.model_6$standardDeviation

et <- abs(rtm.outsample - mean(rtm.outsample))   
#样本外均值的绝对偏差

    ##  计算“月度的已实现波动率RV”(***)
rtd.HSI.2013 <- rtd.HSI['2013']       
head(rtd.HSI.2013)    ;  tail(rtd.HSI.2013)
(rv <- sqrt(aggregate(rtd.HSI.2013^2, by=substr(index(rtd.HSI.2013), 1, 7), sum)))
   #aggregrate():按by设定的时间规则，"加总FUn计算"一个timeseries对象（这里是求和）
   #以日度数据为基础，计算月度的已实现波动率RV :rv(t)=sqrt(sum(r(t,n)^2))
   #提取日度时间索引的前七个字符串（提取年-月），其值不变时，为一个加总计算集合

predVol <- round(rbind(predVol_1,predVol_2,predVol_3,predVol_4,predVol_5,predVol_6, 
                       as*.nume*ric(et), as.numeric(rv)), digits=3)
            #按行纵向合并的矩阵8*11的矩阵
            #每行，均为一个长度为11期的数值向量
colnames(predVol) <- 1:11
rownames(predVol) <- c('GARCH(1,1)-N模型','GARCH(1,2)-N模型','GARCH(1,1)-t模型','GARCH(1,1)-st模型',
                       'GARCH(1,1)-GED模型','GARCH(1,1)-SGED模型','ֵ残差绝对值', '已实现波动率')
print(predVol)

     ## 9) 模型对照
cor(t(predVol))  #矩阵转置，按“列/模型类别”，计算波动率预测的相关系数   
    











### 5. 例6-5：案例分析, GARCH-M模型、TGARCH模型与APARCH模型
library(rugarch)
    ## 1) GARCH-M模型
GARCHM.spec <- ugarchspec(variance.model=list(model='fGARCH', garchOrder=c(1,1), submodel='GARCH'), 
                          mean.model=list(armaOrder=c(0,0), include.mean=TRUE, archm=TRUE),
                          distribution.model='norm')
?ugarchspec
GARCHM.fit <- ugarchfit(GARCHM.spec, data=rtm.insample)
GARCHM.fit




    ## 2) TGARCH模型
TGARCH.spec <- ugarchspec(variance.model=list(model='fGARCH', garchOrder=c(1,1), submodel='TGARCH'), 
                          mean.model=list(armaOrder=c(0,0), include.mean=TRUE, archm=FALSE),
                          distribution.model='norm')
TGARCH.fit <- ugarchfit(TGARCH.spec, data=rtm.insample)
TGARCH.fit
    



    ## 3) APARCH模型
library(fGarch)
APARCH.model_1 <- garchFit(~1+aparch(1,1), data=rtm.insample, trace=FALSE)                    
summary(APARCH.model_1)
APARCH.model_2 <- garchFit(~1+aparch(1,1), data=rtm.insample, delta=2, trace=FALSE)                    
summary(APARCH.model_2)



###  补充：利用“rugarch包”，估计APARCH模型
    ## 3) APARCH模型
library(rugarch)
APARCH.spec <- ugarchspec(variance.model=list(model='fGARCH', garchOrder=c(1,1), submodel='APARCH'), 
                          mean.model=list(armaOrder=c(0,0), include.mean=TRUE, archm=FALSE),
                          distribution.model='norm')
APARCH.fit <- ugarchfit(APARCH.spec, data=rtm.insample)
APARCH.fit
   




