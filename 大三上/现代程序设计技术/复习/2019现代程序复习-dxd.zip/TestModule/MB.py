class B:
    name = 'B'