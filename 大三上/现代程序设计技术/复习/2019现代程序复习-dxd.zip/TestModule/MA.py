class A:
    name = "A"